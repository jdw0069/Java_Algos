import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {
   
    private Node firstNode; //start
    private Node lastNode; //end
    private int size; //number of elements 

    //private helper class for nodes
    private class Node {
        private Item item;
        private Node next;
        private Node previous;

    }
    // construct an empty deque
    public Deque() {
        firstNode = null;
        lastNode = null;
        size = 0;

    }

    // is the deque empty?
    public boolean isEmpty() {
        if (size == 0) {
            return true;
        }
        return false; 
    }

    // return the number of items on the deque
    public int size() {
        return size;
    }

    // add the item to the front
    public void addFirst(Item item) {
        //check for adding null
        if (item == null) {
            throw new IllegalArgumentException();
        }
        //create new Node
        Node newNode = new Node();
        newNode.item = item;
        
        //check for size == 0
        if (size == 0) {
        //head and tail will both poing to new node
         firstNode = newNode;
         lastNode = newNode;
         //set null
         firstNode.previous = null;
         lastNode.next = null;
         size = size + 1;

        }
        
        else {
        
         //head's previous pointer will be newNode
         firstNode.previous = newNode;
         //newNode next pointer will be head
         newNode.next = firstNode;
         //newNode previous pointer assign to null
         newNode.previous = null;
         //assign newNode to be new firstNode
         firstNode = newNode;
         
         size = size + 1;
         
        }
        
        
        
        
    }

    // add the item to the back
    public void addLast(Item item) {
        if (item == null) {
            throw new IllegalArgumentException();
        }
        
        //create new Node
        Node newNode = new Node();
        newNode.item = item;
      
        //check for empty 
        if (size == 0) {
         firstNode = newNode;
         lastNode = newNode;
         firstNode.previous = null;
         lastNode.previous = null;
         
         size = size + 1;
        }
        
        else {
        
        
        //new node will be last node
        lastNode.next = newNode;
        //tail is pointing to second last node
        newNode.previous = lastNode;
        //newly created node will be new tail
        lastNode = newNode;
        //terminate end of list
        lastNode.next = null;
        //increment size
        size = size + 1;
        }
        
    }

     //remove and return the item from the front
    public Item removeFirst() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        
        //get first item to return
        Item returnItem = firstNode.item;
        
        //check for size = 1
        if (size == 1) {
         firstNode = null;
         lastNode = null;
         size = size - 1;
        }
        else {
        //move pointer to next node
        firstNode = firstNode.next;
        //assign new first previous to null
        firstNode.previous = null;
        size = size - 1;
       }
       return returnItem;
    }

     //remove and return the item from the back
    public Item removeLast() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        
        //get last item to return
        Item returnItem = lastNode.item;
        
        //check for only 1 element
        if (size == 1) {
         firstNode = null;
         lastNode = null;
         size = size - 1;
        }
        
        else {
        
        //move pointer to next node
        lastNode = lastNode.previous;
        //assign new first previous to null
        lastNode.next = null;
        size = size - 1;
        }
        return returnItem;
        
    }

    // return an iterator over items in order from front to back
    public Iterator<Item> iterator() {
        return new ListIterator(); 
            
        
    }

    //class for DequeIterator
    private class ListIterator implements Iterator<Item> {
        //create new node
        private Node current = firstNode;
        //hasNext()
        public boolean hasNext() {
            return (current != null);
        }
        //remove (throw arguments)
        public void remove() {
            throw new UnsupportedOperationException();
        }
        //next()
        public Item next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }

            Item item = current.item;
            current = current.next;

            return item;
        }
    }
    // unit testing (required)
    public static void main(String[] args) {
        //Deque<Integer> test = new Deque<Integer>(); 
       // test.addFirst(1);
        //test.addFirst(2);
        //test.addLast(4);
        //test.removeFirst();
        //test.removeLast();
               
    }
}


