import edu.princeton.cs.algs4.WeightedQuickUnionUF;


public class Percolation {

    //global variables
    private int virtualTopRow;
    private int virtualBottomRow;
    private  WeightedQuickUnionUF dataStructure;
    private boolean[][] gridForOpen;
    private int counterForOpenSites;
    private int gridSize;
    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        //grid must be bigger than 0
        if (n <= 0) {
            throw new IllegalArgumentException();
        }

        gridSize = n;
        counterForOpenSites = 0;
        dataStructure = new WeightedQuickUnionUF(n * n + 2); //allow top and bottom virtual
        virtualTopRow = 0;
        virtualBottomRow = n * n + 1;
        gridForOpen = new boolean[n][n];


    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        //call must be in range
        if (row <= 0 || col <=0 || row > gridSize || col > gridSize) {
            throw new IllegalArgumentException();
        }
        //if current position is closed
        if (!isOpen(row, col)) {

            //open spot
            gridForOpen[row-1][col-1] = true;
            counterForOpenSites++;

            int index = xyTo1D(row, col); 

            //if we are on the top row
            if (row == 1) {
                dataStructure.union(virtualTopRow, index);
                
            }

            //if we are on the bottom row
            if (row == gridSize) {
                dataStructure.union(virtualBottomRow, index);
                
            }

            //else, we are somewhere in the middle
            //check for possible neighbors and union

            //left check
            if (row > 1 && isOpen(row-1, col)) {
                dataStructure.union(xyTo1D(row-1, col), index);
                
            }

            //right check
            if (row < gridSize && isOpen(row+1, col)) {
                dataStructure.union(xyTo1D(row+1, col), index);
                
            }

            //up check
            if (col > 1 && isOpen(row, col - 1)) {
                dataStructure.union(xyTo1D(row, col-1), index);
                
            }

            //down check
            if(col < gridSize && isOpen(row, col + 1)) {
                dataStructure.union(xyTo1D(row, col + 1),index);
                
            }

        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        //call must be in range
        if (row <= 0 || col <=0 || row > gridSize || col > gridSize) {
            throw new IllegalArgumentException();
        }

        return gridForOpen[row - 1][col - 1];
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        //call must be in range
        if (row <= 0 || col <=0 || row > gridSize || col > gridSize) {
            throw new IllegalArgumentException();
        }

        return dataStructure.find(xyTo1D(row,col)) == dataStructure.find(virtualTopRow);
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return counterForOpenSites;
    }

    // does the system percolate?
    public boolean percolates() {
        return dataStructure.find(virtualTopRow) == dataStructure.find(virtualBottomRow);
    }

    private int xyTo1D(int i, int j) {
        return (i - 1) * gridSize + j;
    }

    // test client (optional)
    public static void main(String[] args) {
    
    
    }
}