import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private double[] threshold;
    private int tests;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0) {
            throw new IllegalArgumentException();
        }

        //create grid
        tests = trials;
        threshold = new double[tests];

        //run sim
        for(int counter = 0; counter < tests; counter++) {
        Percolation perc = new Percolation(n);
        int openedSites = 0;
        while (!perc.percolates())
        {
          int i = StdRandom.uniform(n)+1;
          int j = StdRandom.uniform(n)+1;
            if (!perc.isOpen(i, j))
            {
                openedSites++;
                perc.open(i, j);
            }
        }
            threshold[counter] = openedSites / (n*n);
     }
    }

    // sample mean of percolation threshold
    public double mean() {
        return StdStats.mean(threshold);
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        if (tests == 1) return Double.NaN;
        return StdStats.stddev(threshold);
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return mean() - ((1.96 * stddev() / Math.sqrt(tests)));
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return mean() + ((1.96 * stddev() / Math.sqrt(tests)));
    }

   // test client (see below)
   public static void main(String[] args) {
       int test = Integer.parseInt(args[0]);
       int test2 = Integer.parseInt(args[1]);


       PercolationStats stats = new PercolationStats(test, test2);
        System.out.println("mean                    = " + stats.mean());
        System.out.println("stddev                  = " + stats.stddev());
        System.out.println("95% confidence interval = " + stats.confidenceLo() + 
                ", " + stats.confidenceHi());
   }

}
